local versions = {
  programVersion = "1.0.4",
  configVersion = 2
}

return versions