local sides = require("sides")

local loggerLib = require("lib.logger-lib")
local discordLoggerHandler = require("lib.logger-handler.discord-logger-handler-lib")
local fileLoggerHandler = require("lib.logger-handler.file-logger-handler-lib")
local scrollListLoggerHandler = require("lib.logger-handler.scroll-list-logger-handler-lib")

local essentiaManager = require("src.essentia-manager")
local infusionManager = require("src.infusion-manager")
local recipeManager = require("src.recipe-manager")

local config = {
  enableAutoUpdate = true, -- Enable auto update on start

  logger = loggerLib:newFormConfig({
    name = "Infusion Control",
    timeZone = 3, -- Your time zone
    handlers = {
      discordLoggerHandler:newFormConfig({
        logLevel = "warning",
        messageFormat = "{Time:%d.%m.%Y %H:%M:%S} [{LogLevel}]: {Message}",
        discordWebhookUrl = "" -- Discord Webhook URL
      }),
      fileLoggerHandler:newFormConfig({
        logLevel = "info",
        messageFormat = "{Time:%d.%m.%Y %H:%M:%S} [{LogLevel}]: {Message}",
        filePath = "logs.log"
      }),
      scrollListLoggerHandler:newFormConfig({
        logLevel = "info",
        logsListSize = 32
      }),
    }
  }),

  maxCpuUse = 3, -- Number of CPUs that can be used to order aspects

  essentiaManager = essentiaManager:newFormConfig({
    mainMeInterfaceAddress = "a41473ed-20d7-4cc6-aae7-f2c0b65b3119" -- Address of the me interface which connected to main ME
  }),

  infusionManager = infusionManager:newFormConfig({
    infusionMeInterfaceAddress = "b7442183-f732-46f4-95d4-3a30eb3b8f91", -- Address of the me interface which connected to infusion ME
    transposerAddress = "0967238c-42fe-4c45-8e7b-6a27d1ab65cf", -- Address of the transposer

    mainMeSide = sides.south, -- Side of the transposer with ME IO Port which connected to main ME
    infusionMeSide = sides.north, -- Side of the transposer with ME IO Port which connected to infusion ME

    redstoneAddress = "ca35780c-8511-4172-b9a3-a8d3b42768b7", -- Address of the Redstone I/O

    infusionClawSide = sides.south, -- Side of the Redstone I/O with Redstone Transmitter of the infusion claw
    infusionClawAcceleratorSide = sides.west, -- Side of the Redstone I/O with Redstone Transmitter of the infusion claw accelerator
    acceleratorSide = sides.north, -- Side of the Redstone I/O with Redstone Transmitter of the matrix accelerator

    infusionClawActivationDelay = 0.5, -- Delay how long to signal the infusion claw
    infusionClawAcceleratorDelay = 1, -- Delay how long to signal the infusion claw accelerator
  }),

  recipeManager = recipeManager:newFormConfig({
    recipeMeInterfaceAddress = "a41473ed-20d7-4cc6-aae7-f2c0b65b3119" -- Address of me interface which will be used to add recipes
  }),
}

return config
